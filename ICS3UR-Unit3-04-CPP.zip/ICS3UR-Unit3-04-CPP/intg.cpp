// Copyright (c) 2020 St. Mother Teresa HS All Rights Reserved.
//
// Created by Gabriel A
// Created on Dec 2020
// This program identifies if the number is positive, negative or 0

#include <iostream>

int main() {
    int integer;

    // input
    std::cout << "Enter a number: ";
    std::cin >> integer;
    std::cout << "" << std::endl;

    if (integer < 0) {
    std::cout << "This is a negative integer.";
    } else if (integer > 0) {
        std::cout << "This is a positive integer.";
    } else {
        std::cout << "This is zero.";
    }
}
